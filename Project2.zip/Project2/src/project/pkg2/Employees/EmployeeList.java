package project.pkg2.Employees;

import project.pkg2.Employees.Employee;

import java.util.ArrayList;

public class EmployeeList {
    public static ArrayList<Employee> employList = new ArrayList<>();
}
