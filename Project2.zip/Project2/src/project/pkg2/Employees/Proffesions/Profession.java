package project.pkg2.Employees.Proffesions;

public class Profession {

    private Titles titles;
    private double salary;
    private double bonus;

    public Profession (Titles tiles){
        this.titles = tiles;
    }


    public Titles getTitles() {
        return titles;
    }

    public void setTitles(Titles titles) {
        this.titles = titles;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = salary*bonus;
    }
}






