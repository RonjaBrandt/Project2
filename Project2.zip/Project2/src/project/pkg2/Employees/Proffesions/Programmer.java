/*

package project.pkg2.Employees.Proffesions;

public class Programmer extends Profession {

    private double salary;
    private double bonus=1;
    private Titles title;


    public Programmer() {
        super();

        this.salary=salary;
        title = Titles.PROGRAMMER;
    }

    public Titles getTitle() {
        return title;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        Salary(salary);
        this.salary = salary;
    }

    public double getBonus() {
        return salary*bonus;
    }

    */
/*public void setBonus(double bonus) {

        this.bonus = bonus;
    }*//*



    @Override
    public String toString() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
*/
