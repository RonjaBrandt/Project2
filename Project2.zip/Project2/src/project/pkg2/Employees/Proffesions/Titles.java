package project.pkg2.Employees.Proffesions;


public enum Titles {
    PROGRAMMER, SALESMAN,SECRETARY,TECHNICIAN
}
