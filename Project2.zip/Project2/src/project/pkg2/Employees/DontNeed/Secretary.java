/*

package project.pkg2.Employees.Proffesions;

public class Secretary extends Profession {


    public Secretary(Titles tiles, double salary, double bonus) {
        super(tiles, salary, bonus);
    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
*/
