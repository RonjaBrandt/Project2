package project.pkg2.Employees;

import project.pkg2.Employees.Utilitis.Gender;
import project.pkg2.Employees.Proffesions.Profession;
import project.pkg2.Employees.Proffesions.Titles;

import static project.pkg2.UI.Main.sc;



public class AddEmployee {

    /* static ArrayList<Employee> employList = new ArrayList<>();*/

    public static void addEmployee() {

        boolean done=false;
        while(done==false) {

            System.out.println("What name has this employee?");
            String name = sc.nextLine();

            System.out.println("Age of the employee: ");
            int age = sc.nextInt();
            sc.nextLine();

            System.out.println("Please state the gender of the employee : \n"
                    + "[1] for male.\n"
                    + "[2] for female.\n"
                    + "or [3] for unspecified. ");
            Gender gender = null;
            int choiceGender = sc.nextInt();
            sc.nextLine();
            switch (choiceGender) {
                case 1:
                    gender = Gender.MALE;
                    break;
                case 2:
                    gender = Gender.FEMALE;
                    break;
                case 3:
                    gender = Gender.OTHER;
                    break;
                default:
                    System.out.println("Sorry, unrecognized option.");
            }
            System.out.println("What title has this employee?\n"
                    + "1. Programmer\n"
                    + "2. Technichian\n"
                    + "3. Secretary\n"
                    + "4. Salesman\n"
                    + "5. Previous Menu");

            Titles titles = null;
            int choiceProfession = sc.nextInt();
            sc.nextLine();

            switch (choiceProfession) {
                case 1:
                    titles = Titles.PROGRAMMER;
                    break;
                case 2:
                    titles = Titles.TECHNICIAN;
                    break;
                case 3:
                    titles = Titles.SECRETARY;
                    break;
                case 4:
                    titles = Titles.SALESMAN;
                    break;
                default:
                    System.out.println("Sorry unrecognized option");
            }

            Profession profession = new Profession(titles) {};

            System.out.println("Enter the salary of the employee: ");
            double salary = sc.nextDouble();
            profession.setSalary(salary);

            System.out.println("Enter the the bonus for the employee: ");
            double bonus = sc.nextDouble();
            profession.setBonus(bonus);

            System.out.println("Do you want to add this employee:"
                    +"\nName: "+ name
                    +"\nAge: " + age
                    +"\nGender: " + gender
                    +"\nWith this roll:"
                    +"\nTitel: "+ titles
                    +"\nSalary: "+salary+ " kr/month"
                    +"\nBonus: "+ bonus +"%"
                    +"\n"
                    +"\n[1]Yes | [2] No, I want to redo it");
            int choiceDone=sc.nextInt();
            switch (choiceDone){
                case 1:
                    Employee employee = new Employee(name,age,gender,profession) {};
                    EmployeeList.employList.add(employee);
                    break;
                case 2:

                default:
                    System.out.println("Something wrong at the end of employee management");
            }
        }
        EmployeeManagement.menu2();
    }
}
