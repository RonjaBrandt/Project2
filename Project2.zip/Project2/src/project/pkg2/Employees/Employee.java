
package project.pkg2.Employees;

import project.pkg2.Employees.Proffesions.Profession;
import project.pkg2.Employees.Utilitis.Gender;

public abstract class Employee {
    
    private String name;
    private int age;
    private Gender gender;
    private Profession profession;
   /* private int id;

    private int nrOfIDs=1;*/

    public Employee(String name, int age, Gender gender, Profession profession) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.profession = profession;
    }


    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public Gender getGender() {
        return gender;
    }

    public Profession getProfession() {
        return profession;
    }
//public abstract String toString();
}
