package project.pkg2.Employees.Utilitis;

public enum Gender {
    MALE, FEMALE, OTHER
}
