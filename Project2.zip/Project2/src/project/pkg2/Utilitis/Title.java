package project.pkg2.Utilitis;


public enum Title {
    PROGRAMMER, SALESMAN,SECRETARY,TECHNICIAN
}
