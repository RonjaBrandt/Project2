package project.pkg2.Utilitis;

public enum Gender {
    MALE, FEMALE, OTHER
}
